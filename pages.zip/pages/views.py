from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import get_user_model
from datetime import datetime, timedelta
from django.core.paginator import Paginator
from decimal import Decimal
import uuid
import urllib.parse
import json
import csv
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.db.models import Sum, Count, Avg, Q

User = get_user_model()


# ==================== PAGES PUBLIQUES ====================

def home(request):
    return render(request, 'pages/home.html')


def login_view(request):
    if request.method == 'POST':
        phone_number = request.POST.get('phone_number')
        password = request.POST.get('password')
        try:
            user = User.objects.get(phone_number=phone_number)
            user = authenticate(username=user.username, password=password)
            if user:
                login(request, user)
                messages.success(request, f'Bienvenue {user.username} !')
                return redirect('pages:dashboard')
            else:
                messages.error(request, 'Mot de passe incorrect')
        except User.DoesNotExist:
            messages.error(request, 'Utilisateur non trouvé')
    return render(request, 'pages/login.html')


def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        role = request.POST.get('role', 'buyer')

        if password != password2:
            messages.error(request, 'Les mots de passe ne correspondent pas')
            return render(request, 'pages/register.html')

        if User.objects.filter(username=username).exists():
            messages.error(request, 'Ce nom d\'utilisateur existe déjà')
            return render(request, 'pages/register.html')

        if User.objects.filter(phone_number=phone_number).exists():
            messages.error(request, 'Ce numéro de téléphone existe déjà')
            return render(request, 'pages/register.html')

        user = User.objects.create_user(
            username=username, email=email, phone_number=phone_number,
            password=password, first_name=first_name, last_name=last_name
        )
        user.role = role
        user.save()

        from wallet.models import Wallet
        Wallet.objects.get_or_create(user_name=user.username, defaults={'balance': 0})

        login(request, user)
        messages.success(request, f'Inscription réussie !')

        if user.role == 'delivery':
            return redirect('pages:delivery_dashboard')
        elif user.role == 'seller':
            return redirect('pages:seller_dashboard')
        else:
            return redirect('pages:buyer_dashboard')

    return render(request, 'pages/register.html')


def logout_view(request):
    logout(request)
    return redirect('pages:home')


def about_view(request):
    return render(request, 'pages/about.html')


def contact_view(request):
    return render(request, 'pages/contact.html')


def faq_view(request):
    return render(request, 'pages/faq.html')


def terms_view(request):
    return render(request, 'pages/terms.html')


# ==================== DASHBOARD ====================

@login_required
def dashboard(request):
    if request.user.role == 'delivery':
        return redirect('pages:delivery_dashboard')
    elif request.user.role == 'seller':
        return redirect('pages:seller_dashboard')
    else:
        return redirect('pages:buyer_dashboard')


@login_required
def buyer_dashboard(request):
    from escrow.models import EscrowTransaction
    from wallet.models import Wallet

    transactions = EscrowTransaction.objects.filter(buyer_name=request.user.username).order_by('-created_at')[:10]
    wallet, _ = Wallet.objects.get_or_create(user_name=request.user.username, defaults={'balance': 0})

    return render(request, 'pages/buyer_dashboard.html', {
        'transactions': transactions,
        'transactions_count': transactions.count(),
        'transactions_completed': EscrowTransaction.objects.filter(buyer_name=request.user.username,
                                                                   completed_at__isnull=False).count(),
        'wallet_balance': int(wallet.balance),
        'now': datetime.now(),
    })


@login_required
def seller_dashboard(request):
    from escrow.models import EscrowTransaction
    from listings.models import Listing
    from wallet.models import Wallet

    all_sales = EscrowTransaction.objects.filter(seller_name=request.user.username)
    completed_sales = all_sales.filter(completed_at__isnull=False)
    total_sales = completed_sales.count()

    total_revenue = 0
    for sale in completed_sales:
        total_revenue += float(sale.amount)

    pending_sales = all_sales.filter(paid_at__isnull=False, shipped_at__isnull=True).count()
    sales = all_sales.order_by('-created_at')[:10]
    listings = Listing.objects.filter(seller_name=request.user.username)
    wallet, _ = Wallet.objects.get_or_create(user_name=request.user.username, defaults={'balance': 0})

    return render(request, 'pages/seller_dashboard.html', {
        'sales': sales,
        'listings': listings,
        'listings_count': listings.count(),
        'total_sales': total_sales,
        'total_revenue': total_revenue,
        'pending_sales': pending_sales,
        'wallet_balance': int(wallet.balance),
        'now': datetime.now(),
    })


@login_required
def delivery_dashboard(request):
    """Dashboard livreur - Version simplifiée"""
    from escrow.models import EscrowTransaction
    from datetime import datetime

    # Livraisons disponibles (commandes expédiées non livrées)
    available_deliveries = EscrowTransaction.objects.filter(
        shipped_at__isnull=False,
        completed_at__isnull=True
    ).order_by('-shipped_at')

    # Compter les livraisons complétées par le livreur
    completed_count = EscrowTransaction.objects.filter(
        completed_at__isnull=False
    ).count()

    total_earnings = completed_count * 2000

    context = {
        'available_deliveries': available_deliveries,
        'my_deliveries': [],
        'completed_deliveries': completed_count,
        'total_earnings': total_earnings,
        'now': datetime.now(),
    }

    return render(request, 'pages/delivery_dashboard.html', context)


@login_required
def profile_view(request):
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name', user.first_name)
        user.last_name = request.POST.get('last_name', user.last_name)
        user.email = request.POST.get('email', user.email)
        user.save()
        messages.success(request, 'Profil mis à jour !')
        return redirect('pages:profile')
    return render(request, 'pages/profile.html', {'user': request.user})


# ==================== ANNONCES ====================

@login_required
def listings_view(request):
    from listings.models import Listing

    listings = Listing.objects.filter(is_available=True).order_by('-created_at')
    paginator = Paginator(listings, 12)
    page_obj = paginator.get_page(request.GET.get('page', 1))
    return render(request, 'pages/listings.html', {'listings': page_obj, 'page_obj': page_obj})


@login_required
def create_listing_view(request):
    from listings.models import Listing

    if request.method == 'POST':
        listing = Listing.objects.create(
            seller_name=request.user.username,
            title=request.POST.get('title'),
            description=request.POST.get('description'),
            price=request.POST.get('price'),
            delivery_fee=request.POST.get('delivery_fee', 0),
        )
        if request.FILES.get('image'):
            listing.image = request.FILES['image']
            listing.save()
        messages.success(request, f'Annonce "{listing.title}" créée !')
        return redirect('pages:listings')
    return render(request, 'pages/create_listing.html')


@login_required
def listing_detail_view(request, listing_id):
    from listings.models import Listing
    from escrow.models import EscrowTransaction
    from decimal import Decimal

    listing = Listing.objects.get(id=listing_id)
    listing.views_count += 1
    listing.save()

    if request.method == 'POST' and request.user.role == 'buyer' and listing.seller_name != request.user.username:
        if listing.stock_quantity > 0:
            transaction = EscrowTransaction.objects.create(
                buyer_name=request.user.username,
                seller_name=listing.seller_name,
                listing_id=str(listing.id),
                listing_title=listing.title,
                amount=listing.price,
                fee=listing.price * Decimal('0.01'),
                delivery_fee=listing.delivery_fee,
                total=listing.price + (listing.price * Decimal('0.01')) + listing.delivery_fee,
                payment_method=request.POST.get('payment_method', 'wave'),
            )
            listing.stock_quantity -= 1
            listing.save()
            messages.success(request, 'Transaction créée !')
            return redirect('pages:transaction_detail', transaction_id=transaction.id)
        else:
            messages.error(request, 'Désolé, ce produit n\'est plus en stock')

    return render(request, 'pages/listing_detail.html', {'listing': listing})


@login_required
def edit_listing_view(request, listing_id):
    from listings.models import Listing

    listing = Listing.objects.get(id=listing_id)
    if listing.seller_name != request.user.username:
        messages.error(request, 'Non autorisé')
        return redirect('pages:listings')

    if request.method == 'POST':
        listing.title = request.POST.get('title')
        listing.description = request.POST.get('description')
        listing.price = request.POST.get('price')
        listing.delivery_fee = request.POST.get('delivery_fee', 0)
        listing.is_available = request.POST.get('is_available') == 'on'
        if request.FILES.get('image'):
            listing.image = request.FILES['image']
        listing.save()
        messages.success(request, 'Annonce modifiée !')
        return redirect('pages:listings')
    return render(request, 'pages/edit_listing.html', {'listing': listing})


@login_required
def delete_listing_view(request, listing_id):
    from listings.models import Listing

    try:
        listing = Listing.objects.get(id=listing_id)
    except Listing.DoesNotExist:
        messages.error(request, 'Annonce non trouvée')
        return redirect('pages:seller_dashboard')

    if listing.seller_name != request.user.username:
        messages.error(request, 'Non autorisé')
        return redirect('pages:listings')

    if request.method == 'POST':
        titre = listing.title
        if listing.image:
            listing.image.delete()
        listing.delete()
        messages.success(request, f'Annonce "{titre}" supprimée !')
        return redirect('pages:seller_dashboard')

    return render(request, 'pages/delete_listing_confirm.html', {'listing': listing})


@login_required
def favorites_view(request):
    from favorites.models import Favorite
    from listings.models import Listing

    favorites = Favorite.objects.filter(user_name=request.user.username)
    favorite_listings = []
    for fav in favorites:
        try:
            listing = Listing.objects.get(id=fav.listing_id)
            favorite_listings.append(listing)
        except:
            pass
    return render(request, 'pages/favorites.html', {'favorites': favorite_listings})


# ==================== TRANSACTIONS ====================

@login_required
def transactions_view(request):
    from escrow.models import EscrowTransaction

    transactions = EscrowTransaction.objects.filter(
        buyer_name=request.user.username
    ) | EscrowTransaction.objects.filter(
        seller_name=request.user.username
    )
    return render(request, 'pages/transactions.html', {'transactions': transactions.order_by('-created_at')})


@login_required
def transaction_detail_view(request, transaction_id):
    from escrow.models import EscrowTransaction

    transaction = EscrowTransaction.objects.get(id=transaction_id)

    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'pay' and transaction.buyer_name == request.user.username:
            transaction.payment_verified = True
            transaction.paid_at = datetime.now()
            transaction.save()
            messages.success(request, 'Paiement confirmé !')
        elif action == 'ship' and transaction.seller_name == request.user.username:
            transaction.shipped_at = datetime.now()
            transaction.save()
            messages.success(request, f'Expédié ! Code OTP: {transaction.delivery_otp}')
        elif action == 'complete' and transaction.buyer_name == request.user.username:
            transaction.completed_at = datetime.now()
            transaction.save()
            messages.success(request, 'Livraison confirmée !')
        return redirect('pages:transaction_detail', transaction_id=transaction.id)

    return render(request, 'pages/transaction_detail.html', {
        'transaction': transaction,
        'is_buyer': transaction.buyer_name == request.user.username,
        'is_seller': transaction.seller_name == request.user.username,
    })


# ==================== PORTEFEUILLE ====================

@login_required
def wallet_view(request):
    from wallet.models import Wallet
    wallet, _ = Wallet.objects.get_or_create(user_name=request.user.username, defaults={'balance': 0})
    return render(request, 'pages/wallet.html', {'wallet': wallet})


@login_required
def withdraw_request(request):
    from wallet.models import Wallet

    if request.method == 'POST':
        amount = float(request.POST.get('amount', 0))
        wallet = Wallet.objects.get(user_name=request.user.username)
        if amount <= 0:
            messages.error(request, 'Montant invalide')
        elif amount > float(wallet.balance):
            messages.error(request, 'Solde insuffisant')
        elif amount < 1000:
            messages.error(request, 'Minimum 1000 FCFA')
        else:
            wallet.balance -= amount
            wallet.save()
            messages.success(request, f'Retrait de {amount} FCFA demandé')
        return redirect('pages:wallet')
    return redirect('pages:wallet')


@login_required
def recharge_wallet_view(request):
    from wallet.models import Wallet
    from decimal import Decimal

    wallet, _ = Wallet.objects.get_or_create(user_name=request.user.username, defaults={'balance': 0})

    if request.method == 'POST':
        amount = Decimal(request.POST.get('amount', 0))

        if amount < 100:
            messages.error(request, 'Le montant minimum est de 100 FCFA')
            return redirect('pages:recharge_wallet')

        if amount > 500000:
            messages.error(request, 'Le montant maximum est de 500 000 FCFA')
            return redirect('pages:recharge_wallet')

        wallet.balance += amount
        wallet.save()

        messages.success(request,
                         f'✅ Recharge de {amount:,.0f} FCFA effectuée ! Nouveau solde: {int(wallet.balance)} FCFA')
        return redirect('pages:wallet')

    return render(request, 'pages/recharge_wallet.html', {
        'wallet_balance': wallet.balance,
        'user': request.user,
    })


@login_required
def recharge_history_view(request):
    return render(request, 'pages/recharge_history.html', {'recharges': []})


# ==================== LIEN DE PAIEMENT ====================

@login_required
def generate_payment_link(request, listing_id):
    from listings.models import Listing
    from escrow.models import EscrowTransaction
    from decimal import Decimal

    listing = Listing.objects.get(id=listing_id)

    if listing.seller_name != request.user.username:
        messages.error(request, 'Non autorisé')
        return redirect('pages:listing_detail', listing_id=listing_id)

    if request.method == 'POST':
        buyer_first_name = request.POST.get('buyer_first_name')
        buyer_last_name = request.POST.get('buyer_last_name')
        buyer_city = request.POST.get('buyer_city')
        buyer_phone = request.POST.get('buyer_phone')
        delivery_company = request.POST.get('delivery_company')
        delivery_address = request.POST.get('delivery_address', '')
        buyer_email = request.POST.get('buyer_email', '')

        if not all([buyer_first_name, buyer_last_name, buyer_city, buyer_phone]):
            messages.error(request, 'Veuillez remplir tous les champs obligatoires')
            return redirect('pages:generate_payment_link', listing_id=listing.id)

        amount = float(listing.price)
        fee = amount * 0.01
        delivery = float(listing.delivery_fee)
        total = amount + fee + delivery

        transaction = EscrowTransaction.objects.create(
            buyer_name=f"{buyer_first_name} {buyer_last_name}",
            buyer_first_name=buyer_first_name,
            buyer_last_name=buyer_last_name,
            buyer_phone=buyer_phone,
            buyer_city=buyer_city,
            buyer_email=buyer_email,
            delivery_company=delivery_company,
            delivery_address=delivery_address,
            seller_name=request.user.username,
            listing_id=str(listing.id),
            listing_title=listing.title,
            amount=Decimal(str(amount)),
            fee=Decimal(str(fee)),
            delivery_fee=Decimal(str(delivery)),
            total=Decimal(str(total)),
            payment_verified=False,
        )

        payment_link = f"http://127.0.0.1:8000/payment-link/{transaction.id}/"

        message = f"""💎 OCALM - Paiement sécurisé 💎

Bonjour {buyer_first_name} {buyer_last_name},

Voici votre lien de paiement sécurisé.

📦 Produit : {listing.title}
💰 Montant : {amount:,.0f} FCFA
🔖 Frais (1%) : {fee:,.0f} FCFA
🚚 Livraison : {delivery:,.0f} FCFA
💎 TOTAL : {total:,.0f} FCFA
📍 Ville : {buyer_city}

🔗 LIEN DE PAIEMENT :
{payment_link}

🔒 Paiement sécurisé - Fonds bloqués jusqu'à livraison

Merci de votre confiance !
✨ L'équipe OCALM"""

        encoded_message = urllib.parse.quote(message)
        whatsapp_link = f"https://wa.me/{buyer_phone.replace('+', '').replace(' ', '')}?text={encoded_message}"

        context = {
            'listing': listing,
            'transaction': transaction,
            'payment_link': payment_link,
            'whatsapp_link': whatsapp_link,
            'facebook_link': f"https://www.facebook.com/sharer/sharer.php?u={urllib.parse.quote(payment_link)}",
        }

        return render(request, 'pages/payment_link_share.html', context)

    return render(request, 'pages/generate_payment_link_form.html', {'listing': listing})


@login_required
def payment_link_view(request, transaction_id):
    from escrow.models import EscrowTransaction
    from listings.models import Listing

    transaction = EscrowTransaction.objects.get(id=transaction_id)

    try:
        listing = Listing.objects.get(id=transaction.listing_id)
    except:
        listing = None

    if request.method == 'POST':
        transaction.buyer_name = request.user.username
        transaction.payment_method = request.POST.get('payment_method')
        transaction.save()
        messages.success(request, 'Paiement initié !')
        return redirect('pages:transaction_detail', transaction_id=transaction.id)

    return render(request, 'pages/payment_link.html', {
        'transaction': transaction,
        'listing': listing
    })


# ==================== LIVRAISONS ====================

@login_required
def take_delivery(request, delivery_id):
    """Prendre une livraison en charge"""
    from escrow.models import EscrowTransaction

    try:
        transaction = EscrowTransaction.objects.get(id=delivery_id)
        if transaction.shipped_at and not transaction.completed_at:
            transaction.delivery_driver = request.user.username
            transaction.save()
            messages.success(request, 'Livraison prise en charge !')
        else:
            messages.error(request, 'Livraison non disponible')
    except EscrowTransaction.DoesNotExist:
        messages.error(request, 'Livraison non trouvée')

    return redirect('pages:delivery_dashboard')


@login_required
def update_location(request, delivery_id):
    """Mettre à jour la position GPS du livreur"""
    from escrow.models import EscrowTransaction

    if request.method == 'POST':
        lat = request.POST.get('latitude')
        lng = request.POST.get('longitude')
        if lat and lng:
            # Sauvegarder la position (à implémenter avec un modèle)
            messages.success(request, 'Position mise à jour !')
        return redirect('pages:delivery_dashboard')

    return render(request, 'pages/update_location.html', {'delivery_id': delivery_id})


@login_required
def check_new_deliveries(request):
    """Vérifier les nouvelles livraisons disponibles (AJAX)"""
    from escrow.models import EscrowTransaction

    new_count = EscrowTransaction.objects.filter(
        shipped_at__isnull=False,
        completed_at__isnull=True
    ).count()

    return JsonResponse({
        'new_count': new_count,
        'success': True
    })


# ==================== RÉSEAUX SOCIAUX ====================

def connect_facebook(request):
    return redirect("https://www.facebook.com/login.php")


def connect_instagram(request):
    return redirect("https://www.instagram.com/accounts/login/")


def connect_tiktok(request):
    return redirect("https://www.tiktok.com/login")


@login_required
def social_media_dashboard(request):
    from listings.models import Listing
    from wallet.models import Wallet
    from datetime import datetime, timedelta

    if request.user.role != 'seller':
        messages.error(request, 'Accès réservé aux vendeurs')
        return redirect('pages:dashboard')

    listings = Listing.objects.filter(seller_name=request.user.username)
    wallet, _ = Wallet.objects.get_or_create(user_name=request.user.username, defaults={'balance': 0})

    total_views = sum(l.views_count for l in listings)

    context = {
        'listings': listings,
        'wallet_balance': int(wallet.balance),
        'total_views': total_views,
    }

    return render(request, 'pages/social_media_dashboard.html', context)


# ==================== MARKETING ====================

@login_required
@require_http_methods(["POST"])
def promote_listing(request):
    try:
        from listings.models import Listing
        from wallet.models import Wallet
        import json

        data = json.loads(request.body)
        listing_id = data.get('listing_id')
        promote = data.get('promote', True)

        listing = Listing.objects.get(id=listing_id, seller_name=request.user.username)
        wallet, _ = Wallet.objects.get_or_create(user_name=request.user.username, defaults={'balance': 0})

        if promote:
            if float(wallet.balance) >= 500:
                wallet.balance -= 500
                wallet.save()
                listing.is_promoted = True
                listing.save()
                return JsonResponse({'success': True, 'message': '✅ Annonce sponsorisée !'})
            else:
                return JsonResponse({'success': False, 'error': '❌ Solde insuffisant !'})
        else:
            listing.is_promoted = False
            listing.save()
            return JsonResponse({'success': True, 'message': 'Sponsorisation désactivée'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["POST"])
def update_featured(request):
    try:
        from listings.models import Listing
        import json

        data = json.loads(request.body)
        featured_ids = data.get('featured_listings', [])

        Listing.objects.filter(seller_name=request.user.username).update(is_featured=False)

        for listing_id in featured_ids:
            Listing.objects.filter(id=listing_id, seller_name=request.user.username).update(is_featured=True)

        return JsonResponse({'success': True, 'message': '✅ Produits vedettes mis à jour'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["POST"])
def create_promo_code(request):
    try:
        from marketing.models import PromoCode
        import json

        data = json.loads(request.body)
        code = data.get('code', '').upper()
        discount = data.get('discount')

        if not code or not discount:
            return JsonResponse({'success': False, 'error': 'Veuillez remplir tous les champs'})

        if int(discount) < 1 or int(discount) > 90:
            return JsonResponse({'success': False, 'error': 'La réduction doit être entre 1% et 90%'})

        if PromoCode.objects.filter(code=code, seller_name=request.user.username).exists():
            return JsonResponse({'success': False, 'error': 'Ce code existe déjà'})

        PromoCode.objects.create(
            seller_name=request.user.username,
            code=code,
            discount=int(discount)
        )
        return JsonResponse({'success': True, 'message': f'✅ Code promo {code} créé'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


@login_required
@require_http_methods(["POST"])
def delete_promo_code(request):
    try:
        from marketing.models import PromoCode
        import json

        data = json.loads(request.body)
        promo_id = data.get('promo_id')

        PromoCode.objects.filter(id=promo_id, seller_name=request.user.username).delete()
        return JsonResponse({'success': True, 'message': '✅ Code promo supprimé'})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})


# ==================== ADMIN ====================

@login_required
def admin_dashboard(request):
    if request.user.role != 'admin' and not request.user.is_superuser:
        messages.error(request, 'Accès non autorisé')
        return redirect('pages:dashboard')

    from accounts.models import User
    from escrow.models import EscrowTransaction
    from listings.models import Listing
    from wallet.models import Wallet
    from django.db.models import Sum

    total_users = User.objects.count()
    buyers = User.objects.filter(role='buyer').count()
    sellers = User.objects.filter(role='seller').count()
    delivery_men = User.objects.filter(role='delivery').count()

    total_transactions = EscrowTransaction.objects.count()
    total_volume = EscrowTransaction.objects.aggregate(Sum('total'))['total__sum'] or 0

    context = {
        'total_users': total_users,
        'buyers': buyers,
        'sellers': sellers,
        'delivery_men': delivery_men,
        'total_transactions': total_transactions,
        'total_volume': total_volume,
        'now': datetime.now(),
    }

    return render(request, 'pages/admin_dashboard.html', context)


# ==================== BADGES (temporaires) ====================

@login_required
def my_badges(request):
    return render(request, 'pages/my_badges.html', {'user_badges': [], 'available_badges': [], 'total_badges': 0})


@login_required
def challenges(request):
    return render(request, 'pages/challenges.html', {'challenges': []})


@login_required
def leaderboard(request):
    return render(request, 'pages/leaderboard.html', {'top_buyers': [], 'top_sellers': [], 'top_delivery': []})


# ==================== COMPARAISON (temporaire) ====================

@login_required
def compare_products(request):
    return render(request, 'pages/compare_products.html', {'products': []})


from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json


@csrf_exempt
def mobile_login(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        phone_number = data.get('phone_number')
        password = data.get('password')

        from django.contrib.auth import authenticate
        from accounts.models import User

        try:
            user = User.objects.get(phone_number=phone_number)
            user = authenticate(username=user.username, password=password)
            if user:
                return JsonResponse({
                    'success': True,
                    'user_id': user.id,
                    'username': user.username,
                    'role': user.role,
                    'phone': user.phone_number
                })
        except:
            pass

        return JsonResponse({'success': False, 'error': 'Identifiants invalides'}, status=401)

    return JsonResponse({'error': 'Method not allowed'}, status=405)


def mobile_listings(request):
    from listings.models import Listing

    listings = Listing.objects.filter(is_available=True).values(
        'id', 'title', 'price', 'delivery_fee', 'seller_name'
    )

    # Convertir en liste
    data = list(listings)
    for item in data:
        item['price'] = str(item['price'])
        item['delivery_fee'] = str(item['delivery_fee'])

    return JsonResponse(data, safe=False)


def mobile_listing_detail(request, listing_id):
    from listings.models import Listing

    try:
        listing = Listing.objects.get(id=listing_id)
        return JsonResponse({
            'id': str(listing.id),
            'title': listing.title,
            'description': listing.description,
            'price': str(listing.price),
            'delivery_fee': str(listing.delivery_fee),
            'seller': listing.seller_name,
            'is_available': listing.is_available
        })
    except Listing.DoesNotExist:
        return JsonResponse({'error': 'Product not found'}, status=404)

    @login_required
    def check_notifications(request):
        from escrow.models import EscrowTransaction
        from datetime import datetime, timedelta

        new_orders = EscrowTransaction.objects.filter(
            seller_name=request.user.username,
            created_at__gte=datetime.now() - timedelta(hours=1),
            paid_at__isnull=True
        ).count()

        return JsonResponse({'new_orders': new_orders})

    import pyotp

    def enable_2fa(request):
        secret = pyotp.random_base32()
        request.session['2fa_secret'] = secret
        totp = pyotp.TOTP(secret)
        qrcode = totp.provisioning_uri(request.user.email, issuer_name="OCALM")
        return render(request, 'pages/enable_2fa.html', {'qrcode': qrcode, 'secret': secret})

    import stripe
    from django.conf import settings

    stripe.api_key = settings.STRIPE_SECRET_KEY

    def create_payment(request, amount):
        if request.method == 'POST':
            intent = stripe.PaymentIntent.create(
                amount=int(amount * 100),
                currency='xof',
                metadata={'user_id': request.user.id}
            )
            return JsonResponse({'clientSecret': intent.client_secret})

        return render(request, 'pages/payment_stripe.html', {'amount': amount})

    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from django.http import HttpResponse

    def generate_invoice(request, transaction_id):
        from escrow.models import EscrowTransaction

        transaction = EscrowTransaction.objects.get(id=transaction_id)

        response = HttpResponse(content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="facture_{transaction.reference}.pdf"'

        p = canvas.Canvas(response, pagesize=A4)
        p.drawString(100, 800, f"FACTURE N° {transaction.reference}")
        p.drawString(100, 780, f"Produit: {transaction.listing_title}")
        p.drawString(100, 760, f"Montant: {transaction.total} FCFA")
        p.drawString(100, 740, f"Date: {transaction.created_at.strftime('%d/%m/%Y')}")
        p.save()

        return response

    @login_required
    def get_recommendations_api(request):
        from escrow.models import EscrowTransaction
        from listings.models import Listing
        from ml.recommendations import get_recommendations

        user_purchases = EscrowTransaction.objects.filter(buyer_name=request.user.username)
        all_products = Listing.objects.filter(is_available=True).values('id', 'title', 'description')

        recommendations = get_recommendations(request.user.username, user_purchases, all_products)

        return JsonResponse({'recommendations': recommendations})