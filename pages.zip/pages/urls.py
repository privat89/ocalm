from django.urls import path
from . import views

app_name = 'pages'

urlpatterns = [
    # Pages publiques
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('about/', views.about_view, name='about'),
    path('contact/', views.contact_view, name='contact'),
    path('faq/', views.faq_view, name='faq'),
    path('terms/', views.terms_view, name='terms'),

    # Dashboard
    path('dashboard/', views.dashboard, name='dashboard'),
    path('buyer/dashboard/', views.buyer_dashboard, name='buyer_dashboard'),
    path('seller/dashboard/', views.seller_dashboard, name='seller_dashboard'),
    path('delivery/dashboard/', views.delivery_dashboard, name='delivery_dashboard'),
    path('profile/', views.profile_view, name='profile'),

    # Annonces
    path('listings/', views.listings_view, name='listings'),
    path('listing/create/', views.create_listing_view, name='create_listing'),
    path('listing/<str:listing_id>/', views.listing_detail_view, name='listing_detail'),
    path('listing/<str:listing_id>/edit/', views.edit_listing_view, name='edit_listing'),
    path('listing/<str:listing_id>/delete/', views.delete_listing_view, name='delete_listing'),
    path('favorites/', views.favorites_view, name='favorites'),

    # Transactions
    path('transactions/', views.transactions_view, name='transactions'),
    path('transaction/<str:transaction_id>/', views.transaction_detail_view, name='transaction_detail'),

    # Paiement
    path('generate-payment-link/<str:listing_id>/', views.generate_payment_link, name='generate_payment_link'),
    path('payment-link/<str:transaction_id>/', views.payment_link_view, name='payment_link_view'),

    # Portefeuille
    path('wallet/', views.wallet_view, name='wallet'),
    path('withdraw/', views.withdraw_request, name='withdraw'),
    path('wallet/recharge/', views.recharge_wallet_view, name='recharge_wallet'),
    path('wallet/recharge/history/', views.recharge_history_view, name='recharge_history'),

    # Livraisons
    path('delivery/take/<int:delivery_id>/', views.take_delivery, name='take_delivery'),
    path('delivery/update-location/<int:delivery_id>/', views.update_location, name='update_location'),
    path('delivery/check-new/', views.check_new_deliveries, name='check_new_deliveries'),

    # Marketing
    path('marketing/dashboard/', views.social_media_dashboard, name='social_media_dashboard'),
    path('marketing/connect/facebook/', views.connect_facebook, name='connect_facebook'),
    path('marketing/connect/instagram/', views.connect_instagram, name='connect_instagram'),
    path('marketing/connect/tiktok/', views.connect_tiktok, name='connect_tiktok'),
    path('marketing/promote/', views.promote_listing, name='promote_listing'),
    path('marketing/featured/', views.update_featured, name='update_featured'),
    path('marketing/create-promo/', views.create_promo_code, name='create_promo_code'),
    path('marketing/delete-promo/', views.delete_promo_code, name='delete_promo_code'),

    # Admin
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),

    # Badges
    path('badges/', views.my_badges, name='my_badges'),
    path('challenges/', views.challenges, name='challenges'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
# Ajouter ces lignes dans urlpatterns
path('api/login/', views.mobile_login, name='mobile_login'),
path('api/listings/', views.mobile_listings, name='mobile_listings'),
path('api/listings/<str:listing_id>/', views.mobile_listing_detail, name='mobile_listing_detail'),
]
badges = [
    ('🥇 Premier achat', 'fa-shopping-cart', 'A effectué son premier achat', 1, 'buyer'),
    ('🥈 Collectionneur', 'fa-boxes', '10 achats', 10, 'buyer'),
    ('🚀 Top vendeur', 'fa-rocket', '50 ventes', 50, 'seller'),
    ('⭐ Étoile montante', 'fa-star', 'Note moyenne 4.5+', 45, 'seller'),
    ('🚚 Livreur pro', 'fa-truck', '100 livraisons', 100, 'delivery'),
]